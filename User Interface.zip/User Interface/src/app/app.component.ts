import { Component } from '@angular/core';
import { HttpServiceService } from './http-service.service';
import { CartServiceService } from './service/cart-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'spring-angular';
  categoryList: any;
  productsList: any;
  openCheckoutModel(){
    alert("open checkout model");
  }

  constructor(private CartService:CartServiceService, private http:HttpServiceService){
    let request = {}
    
    this.http.postRequest("api/status", request).subscribe(data=>{
      console.log("test", data);
    },error=>{
      alert("Server connection error " + error)
    })

    this.http.postRequestWithToken("api/product/getAllCategory", request).subscribe(data=>{
      this.categoryList = data;
      if(this.categoryList.length > 1)
        this.getProductsByCategory(data[0]);
    },error=>{
      alert("Server connection error " + error)
    })
  }

  addCart(cartProductObj){
    var cartObj = {
      "productId":cartProductObj.id,
      "qty":"1",
      "price":cartProductObj.price
    }
    this.CartService.addCart(cartObj);
  }

  getProductsByCategory(obj){
    let request = {
      "cat_id":obj.id
    }
    this.http.postRequestWithToken('api/product/getProductsByCategory', request).subscribe(data=>{
      this.productsList = data;
      if(this.productsList.length == 0){
        alert("No product is found..");
      }
    },error=>{
      alert("Error in login " + error);
    })
  }
}
