import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from '../http-service.service';
import { CartServiceService } from '../service/cart-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isOpenLoginDialog = false;
  currentDropDownMenu = "";
  dialogType = "login";
  isLogin = false;
  mobile = "";
  password = "";
  cartObj = [];
  cart_qty = 0;
  cartTotalPrice = 0;
  welcomeUsername = "";
  mainDialogType = "";
  register = {
    "name":"",
    "mobile":"",
    "email":"",
    "password":"",
    "re_password":""
  };
  
  constructor(private CartService:CartServiceService, private http:HttpServiceService){
    let request = {}
    this.http.postRequest("api/status", request).subscribe(data=>{
      console.log("test", data);
    },error=>{
      alert("Server connection error " + error)
    })
    if(this.http.isLogin()){
      this.isLogin = true;
      this.welcomeUsername = this.http.getLoginDataByKey("name");
    }

    if(this.http.isLogin()){
      this.isLogin = true;
      this.welcomeUsername = this.http.getLoginDataByKey("name");
    }
    //subscribe to the event emitter in the cart-service
    this.CartService.cartServiceEvent.subscribe(data=>{
      this.cart_qty = this.CartService.getQty();
    })
  }
  logout(){
    this.http.logout();
    this.isLogin = false;
  }

  ngOnInit(): void {
  }

  loginUserCheck(){
    if(this.mobile == ""){
      alert("Mobile should not be empty");
      return;
    }
    if(this.password == ""){
      alert("Password should not be empty");
      return;
    }
    let request = {
      "mobile": this.mobile,
      "password": this.password
    }

    this.http.postRequest('api/login/user', request).subscribe(data=>{
      if(data.hasOwnProperty("token")){
        this.http.setLoginToken(data['token']);
        this.http.setLoginData(data);
        this.welcomeUsername = this.http.getLoginDataByKey("name");
        //console.log("from the login data ", this.http.getLoginDataByKey("email"));
        this.isLogin = true;
        // this.isOpenLoginDialog = false;
        this.mainDialogType = "";
      }
    },error=>{
      alert("Error in login " + error);
    })
  }

  registerUser(){
    if(this.register.name == ""){
      alert("Name should not be empty");
      return
    }
    if(this.register.email == ""){
      alert("Email should not be empty");
      return;
    }
    if(this.register.password == ""){
      alert("Password should not be empty");
      return;
    }
    if(this.register.password != this.register.re_password){
      alert("Password and re_password should be same");
      return;
    }
    if(this.register.mobile == ""){
      alert("Mobile should not be empty");
      return;
    }
    let request = {
      "name":this.register.name,
      "email":this.register.email,
      "password":this.register.password,
      "mobile":this.register.mobile
    }

    this.http.postRequest('api/signup/user', request).subscribe(data=>{
      alert("Register Successfully...");
      this.dialogType = "login";
        // this.http.setLoginToken(data['token']);
        // this.isLogin = true;
    },error=>{
      alert("Error in login " + error);
    })
  }

  openCheckoutModel(){
    this.cartObj = this.CartService.getCartObj();
    this.cartTotalPrice = this.CartService.cartTotalPrice;
    this.mainDialogType = "checkout";
  }

  openDialog() {
    // this.isOpenLoginDialog = true;
    this.mainDialogType = "login";
  }

  closeDialog() {
    // this.isOpenLoginDialog = false;
    this.mainDialogType = "";
  }

  dialogTypeInside(type) {
    if(this.dialogType != type)
      this.dialogType = type;
  }

  currentDropDown(currentDropDownMenuName) {
    if(this.currentDropDownMenu == currentDropDownMenuName) {
      this.currentDropDownMenu = "";
    } else {
      this.currentDropDownMenu = currentDropDownMenuName;
    }
  }

}
