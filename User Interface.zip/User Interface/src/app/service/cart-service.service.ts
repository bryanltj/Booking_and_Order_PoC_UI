import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpServiceService } from '../http-service.service';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {

  public cartServiceEvent = new BehaviorSubject({});
  cartQty = 0;
  cartObj = [];
  public cartTotalPrice = 0;
  constructor(private http:HttpServiceService) { 

  }

  getCartDetailsByUser(){
    this.http.postRequestWithToken("api/addtocart/getCartByUserId", {}).subscribe((data:any)=>{
      //alert("Error while fetching the cart details");
      this.cartObj = data;
      this.cartQty = data.length;
      this.cartTotalPrice = this.getTotalAmountOfTheCart();
      //send the event to all over the application
      this.cartServiceEvent.next({"status":"completed"})//emitter
    },error=>{
      alert("Error while fetching the cart details");
    });
  }

  addCart(obj){
    var request = {
      "productId":obj.productId,
      "qty":obj.qty,
      "price":obj.price
    }
    this.http.postRequestWithToken("api/addtocart/addProduct", request).subscribe((data:any)=>{
      this.getCartDetailsByUser();
    },
    error=>{
      // if product is already in cart
      alert("Error in AddCart API" + error.message);
    })
  }

  getCartObj(){
    return this.cartObj;
  }

  getTotalAmountOfTheCart(){
    let obj = this.cartObj;
    let totalPrice = 0;
    for(var o in obj){
      totalPrice += parseFloat(obj[o]['price']);
    }
    return totalPrice;
  }

  getQty(){
    return this.cartQty;
  }
}
